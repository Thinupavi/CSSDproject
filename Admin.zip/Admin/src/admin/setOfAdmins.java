/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.io.Serializable;
import java.util.Vector;
import javax.swing.JFrame;

/**
 *
 * @author LENOVO
 */
public class setOfAdmins extends Vector<adminClass> implements Serializable{
    
    public setOfAdmins(){
        super();
    }
    
    public void addAdmin(adminClass a){
        super.add(a);
    }
    
    
    public void login(String username,String password){
       for(int i=0;i<super.size();i++){
           if(super.get(i).getusername().contains(username) && super.get(i).getpassword().contains(password)){
               System.out.println(super.get(i).getusername().contains(username));
               System.out.println(super.get(i).getpassword().contains(password));
           
            } 
        }
      
    }
    
   
}
