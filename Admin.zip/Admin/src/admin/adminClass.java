/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.io.Serializable;

/**
 *
 * @author LENOVO
 */
public class adminClass implements Serializable {
  
    private String adminID;
    private String name;
    private String phoneNo;
    private String address;
    private String username;
    private String password;
    
    
    public adminClass(String id,String name,String phone,String address,String username,String password){
        this.adminID=id;
        this.name=name;
        this.phoneNo=phone;
        this.address=address;
        this.username=username;
        this.password=password;
        
    }
    
    public String getAdminId(){
        return adminID;
    }
    public String getname(){
        return name;
    }
    public String getphoneNo(){
        return phoneNo;
    }
    public String getaddress(){
        return address;
    }
    public String getusername(){
        return username;
    }
    public String getpassword(){
        return password;
    }
    
    public void setAdminID(String id){
        this.adminID=id;
    }
    public void setname(String name){
        this.name=name;
    }
    public void setphoneNo(String no){
        this.phoneNo=no;
    }
    public void setaddress(String a){
        this.address=a;
    }
    public void setusername(String username){
        this.username=username;
    }
    public void setpassword(String password){
        this.password=password;
    }
}
